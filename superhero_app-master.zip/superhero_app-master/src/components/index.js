export { default as Superheroes } from './Superheroes/Superheroes';
export { default as Search } from './Search/Search';