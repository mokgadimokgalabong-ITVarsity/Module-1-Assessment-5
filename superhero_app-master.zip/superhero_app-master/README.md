# Superhero Application

[Live Version](https://vigilant-darwin-25f590.netlify.app/)

A web application that uses a Superhero API to fetch data about superheroes. The data can be filtered and searched. The application includes lazy loading and it is fully responsive.
